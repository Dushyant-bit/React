export function Person(){
    return(
        <div>
            <p>Hello Person is Here!!!</p>
        </div>
    );
}