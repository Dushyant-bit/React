import './App.css';
import { Person } from './Person';
function App() {
  function Touched(){
    alert("You Clicked");
  }
  return (
    <div className="App">
      <h1>Hello React</h1>
    </div>
  );
}

export default App;
