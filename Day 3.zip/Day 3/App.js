import { useState } from "react";
import "./App.css";
import { Person } from "./Person";
function App() {
  const [name, setName] = useState("E1");
  return (
    <div className="App">
      <h1>Props in React:</h1>
      <Person data={name} />
      <button onClick={() => setName("E2")}> Update Name</button>
    </div>
  );
}

export default App;
