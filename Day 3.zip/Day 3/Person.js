export function Person(Props){
    return(
        <div>
            <p>Hello {Props.data}</p>
        </div>
    );
}